from flask import Flask, render_template, request, flash, redirect, url_for,jsonify
from flask_mail import Mail, Message
import os
import logging







app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/product')
def bowl_basin():
    return render_template('product.html')

@app.route('/BowlBasin')
def product():
    return render_template('BowlBasin.html')

@app.route('/CONCEALEDCISTERNS')
def concealed_cisterns():
    return render_template('CONCEALEDCISTERNS.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/ElectricUrinal')
def electric_urinal():
    return render_template('ElectricUrinal.html')

@app.route('/free-standing-basin')
def free_standing_basin():
    return render_template('free standingbasin.html')

@app.route('/full-pedestal')
def full_pedestal():
    return render_template('fullpedestal.html')

@app.route('/half-pedestal')
def half_pedestal():
    return render_template('halfpedestal.html')

@app.route('/integrated')
def integrated_view():
    return render_template('integrated.html')

@app.route('/INTEGRATEDBASIN')
def integrated_basin():
    return render_template('INTEGRATEDBASIN.html')

@app.route('/long-pedestal')
def long_pedestal():
    return render_template('longpedestal.html')

@app.route('/POLYMERCISTERNS')
def polymer_cisterns():
    return render_template('POLYMERCISTERNS.html')

@app.route('/integrated')
def integrated():
    return render_template('integrated.html')

@app.route('/SEATCOVERS')
def seat_covers():
    return render_template('SEATCOVERS.html')

@app.route('/single-piece-wc')
def single_piece_wc():
    return render_template('singlepiecewc.html')

@app.route('/WALLHUNG')
def wall_hung():
    return render_template('WALLHUNG.html')

@app.route('/kichen')
def kichen():
    return render_template('kichen.html')

@app.route('/waterheater')
def water_heater():
    return render_template('waterheater.html')

@app.route('/vanity')
def vanity():
    return render_template('vanity.html')

@app.route('/cp')
def cp():
    return render_template('cp.html')

@app.route('/rainshower')
def rainshower():
    return render_template('rainshower.html')


@app.route('/handshower')
def handshower():
    return render_template('handshower.html')


@app.route('/bathtub')
def bathtub():
    return render_template('bathtub.html')

@app.route('/claret')
def claret():
    return render_template('claret.html')


@app.route('/concealed')
def concealed():
    return render_template('concealed.html')


@app.route('/jade')
def jade():
    return render_template('jade.html')


@app.route('/showerpanel')
def showerpanel():
    return render_template('showerpanel.html')

@app.route('/uno')
def uno():
    return render_template('uno.html')

@app.route('/towelstand')
def towelstand():
    return render_template('towelstand.html')

@app.route('/waterman')
def waterman():
    return render_template('waterman.html')


@app.route('/jaquar')
def jaquar():
    return render_template('jaquar.html')


@app.route('/cart')
def cart():
    return render_template('cart.html')


app.secret_key = 'utfi dpma pfoa ycpk '
#  Flask-Mail Configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'sreevelmuruganhardwaretiles@gmail.com'  # Your Gmail Address
app.config['MAIL_PASSWORD'] = 'utfi dpma pfoa ycpk '  # Your Gmail App Password (generated if 2FA is enabled)
app.config['MAIL_DEFAULT_SENDER'] = 'sreevelmuruganhardwaretiles@gmail.com'  # Default sender email



mail = Mail(app)

@app.route("/", methods=["GET", "POST"])
def contact_form():
    if request.method == "POST":
        # Extract form data
        name = request.form["name"]
        phone = request.form["number"]
        item = request.form["subject"]
        model = request.form["message"]

        # Create the email message
        msg = Message("New Contact Form Submission", recipients=["sreevelmuruganhardwaretiles@gmail.com"])
        msg.body = f"""
        Name: {name}
        Phone: {phone}
        Item: {item}
        Model: {model}
        """
        
        # Send the email
        try:

            mail.send(msg)

            flash("Message sent successfully!", "success")

            return render_template("contact.html")  # Redirect to the same page to avoid form resubmission

        except Exception as e:

            flash(f"Error: {str(e)}", "error")

            return redirect(url_for('/contact'))  # Redirect to the same page
    
    return render_template("contact.html")


# Configure Flask-Mail

app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Use Gmail's SMTP server

app.config['MAIL_PORT'] = 587  # Use port 587 for TLS

app.config['MAIL_USE_TLS'] = True  # Enable TLS

app.config['MAIL_USERNAME'] = 'sreevelmuruganhardwaretiles@gmail.com'  # Your Gmail address

app.config['MAIL_PASSWORD'] = 'oegc bbjq zejr poet '  # Use an App Password if 2FA is enabled

app.config['MAIL_DEFAULT_SENDER'] = 'sreevelmuruganhardwaretiles@gmail.com'  # Default sender



mail = Mail(app)


@app.route('/')

def index():

    return render_template('index.html')


@app.route('/checkout', methods=['POST'])

def checkout():

    data = request.json

    user_name = data['userName']

    user_phone = data['userPhone']

    user_location = data['userLocation']
    user_email = data['userEmail']

    payment_mode = data['paymentMode']  # Get the selected payment mode

    card_number = data['cardNumber']

    card_expiry = data['cardExpiry']

    card_cvc = data['cardCVC']

    cart_items = data['cartItems']
  
  

    # Calculate total

    total_amount = sum(item['price'] * item['quantity'] for item in cart_items)


    # Create the email content

    email_body = f"""

    <h1>User Details</h1>

    <p>Name: {user_name}</p>

    <p>Phone: {user_phone}</p>

    <p>Location: {user_location}</p>

    <p>Email: {user_email}</p>
     <p>Payment Mode: {payment_mode}</p>  <!-- Include payment mode -->
     

    <h2>Cart Items</h2>

    <table style="width: 100%; border-collapse: collapse;">

        <tr>

            <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Image</th>

            <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Product Name</th>

            <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Quantity</th>

            <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Price</th>

        </tr>

    """

    

    for item in cart_items:

        email_body += f"""

        <tr>

            <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">

                <img src="{item['image']}" alt="{item['name']}" style="width:100px;height:auto;">

            </td>

            <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">{item['name']}</td>

            <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">{item['quantity']}</td>

            <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">₹{item['price']}</td>

        </tr>

        """

    

    email_body += f"""

    </table>

    <h3 style="text-align: center;">Total Amount: ₹{total_amount}</h3>

    """


    msg = Message("Order Confirmation", recipients=[user_email])

    msg.html = email_body  # Use HTML content


    mail.send(msg)


    return jsonify({"success": True, "message": "Your order has been successfully placed! A confirmation email has been sent."})

    



if __name__ == '__main__':
    app.run(debug=True)




